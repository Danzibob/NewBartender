const drinksData = {
  "Ingredients":[
    'Strawberry Daiquiri Mix',
    'Passion Fruit Martini Mix',
    'Vodka',
    'White Rum',
    //'Disaronno',
    'Tequila',
    'Orange Juice',
    'Blue Curacao'
  ],

  "Cocktails":{

    'Hole In One':{
      'ingredients': {
        'Vodka':1.5,
        'Cranberry Juice':3,
        'Orange Juice':1/8
      },
      'glass': "Large Martini"
    },

    'Grand Cosmo':{
      'ingredients': {
        'Vodka':1.5,
        'Grand Marnier':1,
        'Lime Juice':1/8,
        'Cranberry Juice':2
      },
      'glass': "Large Martini"
    },

    'Ghost Goblet':{
      'ingredients': {
        'Cranberry Juice':8,
        'Vodka':4,
        'Cointreau':2
      },
      'glass': "Large Martini"
    },

    'Tequila Sunrise':{
      'ingredients': {
        'Orange Juice':4,
        'Tequila':2,
        'Grenadine':1/2
      },
      'glass': "Highball"
    },

    'Bocce Ball':{
      'ingredients': {
        'Orange Juice':4,
        'Vodka':2,
        'Disaronno':1
      },
      'glass': "Highball"
    },

    'Ollie':{
      'ingredients': {
        'White Rum':1,
        'Vodka':2,
        'Tequila':1,
        'Lemonade':-1
      },
      'glass': "Highball",
      'instructions':"Drink like a tequila slammer, holding a slice of lemon between your thumb and forefinger of one hand, a pinch of salt resting on the back of the same hand. Lick up the salt, down the drink in one and then bite the slice of lemon."
    },

    'Romeo':{
      'ingredients': {
        'White Rum':1+1/4,
        'Cointreau':1,
        'Lemon Juice':1/2,
        'Strawberry Puree':3
      },
      'glass': "14oz Bulb"
    },

    'Orange Crush':{
      'ingredients': {
        'Vodka':2,
        'Orange Liqueur':1,
        'Orange Juice':3
      },
      'glass': "Collins",
      'instructions':"Don't forget to garnish with orange!"
    },

    'Black Cat':{
      'ingredients': {
        'Tequila':1+1/4,
        'Disaronno':1+1/4
      },
      'glass': "Lowball"
    },

    'Soylent Green':{
      'ingredients': {
        'Vodka':1+1/2,
        'Blue Curacao':1,
        'Orange Juice':4
      },
      'glass': "Collins"
    },

    'Tropical Itch':{
      'ingredients': {
        'Vodka':1,
        'Grand Marnier':1/2,
        'White Rum':1,
        'Passion Fruit Juice':3
      },
      'glass': "Collins"
    },

    'Screwdriver':{
      'ingredients': {
        'Vodka':1+1/2,
        'Orange Juice':4
      },
      'glass': "Lowball"
    },

    'Kamikaze':{
      'ingredients': {
        'Vodka':1/2,
        'Triple Sec':1/4,
        'Lime Juice':1/4
      },
      'glass': "Shot"
    },

    'Godmother':{
      'ingredients': {
        'Vodka':1+1/2,
        'Disaronno':1/2
      },
      'glass': "Lowball"
    }



  },

  "Substitutions":{
    'Grand Marnier':"Blue Curacao",
    'Cointreau':"Blue Curacao",
    'Grenadine':"Blue Curacao",
    'Strawberry Puree': "Strawberry Daiquiri Mix",
    'Orange Liqueur': "Blue Curacao",
    'Passion Fruit Juice': "Passion Fruit Martini Mix",
    'Triple Sec':"Blue Curacao"
  }
}

const drinks = Object.getOwnPropertyNames(drinksData.Cocktails)
var busy = false
var current_rec_pos = 0
var response = {}

exports.run = function (req, res) {
  
  res.set('Content-Type', 'application/json')
  response = {
    "displayText":"",
    "contextOut":[],
    "data": {}
  }

  handle(req.body.result,res)

}

//And now for some functions...

function handle(result,res){
  switch(result.action){

    case "drink_request":
      makeDrink(result.parameters.Drink,res)
      break

    case "surprise_drink":
      var index = Math.floor(Math.random()*drinks.length)
      makeDrink(drinks[index])

    case "recommend_drink":
      recommend(res)
      break

    case "next_rec":
      nextRec(res)
      break

    case "get_recipe":
      getRecipe(result.parameters,res)
      break

    //Add more cases for different actions here

    default:
      console.log("yer what m8")
  }
}

function makeDrink(drinkName,res){
  if(!busy){
    console.log("Making a",drinkName)
    res.send(response)
    busy = true
    //Tell arduino the ingredients and amounts
    setTimeout(function() {busy = false}, 5000);
  } else {
    console.log("I can't I'm busy")
    response["speech"] = "Sorry I'm busy right now"
    res.send(response)
    //Flash lights red
  }
  
}

function recommend(res){
  console.log("Shuffling list")
  drinks = shuffle(drinks)
  current_rec_pos = -1
  nextRec(res)
}

function nextRec(res){
  current_rec_pos++
  if(current_rec_pos >= drinks.length){
    response["speech"] = "Sorry, that's all the drinks I know how to make"
  } else {
    response["speech"] = ivegota() + drinks[current_rec_pos]
    response["contextOut"] = [{
      "name":"recommended",
      "lifespan":2,
      "parameters":{"Drink":drinks[current_rec_pos]}
    }]
  }
  res.send(response)
}

function getRecipe(args,res){
  var drink = args.Drink
  console.log("Getting recipe for",drink)
  var list = drinksData[drink]
  if(list != undefined){
    list = list.join(", ").replace(/,([^,]*)$/," and"+'$1')
    response["speech"] = ingredients(drink) + list
  }
  res.send(response)
}

//And here come the helper functions...
function shuffle(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}

function ivegota(){
  var choices = [
    "I've got a ",
    "You could try a ",
    "How about a ",
    "Would you like a ",
    "I could do you a ",
    "There's a ",
    "Well there's a "
  ]
  var index = Math.floor(Math.random()*choices.length)
  return choices[index]
}

function ingredients(drink){
  var A = ["A ","You make a ","To make a "]
  var B = [" contains "," with "," you use "]
  var index = Math.floor(Math.random()*A.length)
  return A[index] + drink + B[index]

}